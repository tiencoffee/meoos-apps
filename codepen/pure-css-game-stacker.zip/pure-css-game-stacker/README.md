# Pure CSS Game: Stacker

A Pen created on CodePen.io. Original URL: [https://codepen.io/jerrylow/pen/WMNdzr](https://codepen.io/jerrylow/pen/WMNdzr).

A pure CSS game of Stacker. Unfortunately the recursive function made the CSS way too big for Codepen. I've reduce the rows by two and compressed it. For the full game (12 rows) and source: https://gist.github.com/jerrylow/f0f39cc3d1036515e4f23944516d5f2a