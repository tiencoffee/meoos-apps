# Just a little game

A Pen created on CodePen.io. Original URL: [https://codepen.io/FWeinb/pen/DZpVpw](https://codepen.io/FWeinb/pen/DZpVpw).

Wrote a little Blog post about it: http://blog.weinberg.me/2013/04/20/Continuously-rotating-element/