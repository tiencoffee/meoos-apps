# Brainymo - Memory game

A Pen created on CodePen.io. Original URL: [https://codepen.io/davinci/pen/yVZapY](https://codepen.io/davinci/pen/yVZapY).

Frontend technologies memory game.
For best experience open in full page view :)