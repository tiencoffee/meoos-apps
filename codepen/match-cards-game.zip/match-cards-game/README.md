# Match Cards Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/max131/pen/zYZePzX](https://codepen.io/max131/pen/zYZePzX).

A simple and pretty match cards game.