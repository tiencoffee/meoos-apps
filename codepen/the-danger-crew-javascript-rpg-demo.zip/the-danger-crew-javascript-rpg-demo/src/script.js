/* Built with React & Redux */
/* thedangercrew.com */

/* It helps to use the side view of the CodePen editor when playing the game. Change View -> Editor Layout -> Choose either the left or right option. Debug View is a good option, too :D */

/* created by: David Stout, Henry Leacock, & Drew Conley */