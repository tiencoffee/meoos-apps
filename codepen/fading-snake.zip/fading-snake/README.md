# Fading Snake

A Pen created on CodePen.io. Original URL: [https://codepen.io/HunorMarton/pen/dyXjaza](https://codepen.io/HunorMarton/pen/dyXjaza).

No libraries, no preprocessors, no imports not even SVG or canvas. Just plain HTML, CSS, and JavaScript. Check out the source code, for detailed comments.

If you want to know how this game was made, watch the quick introduction for it on [YouTube](https://youtu.be/TAmYp4jKWoM) that explains the main game logic and the transitioning effect.


Follow me on [Twitter](https://twitter.com/HunorBorbely) for more