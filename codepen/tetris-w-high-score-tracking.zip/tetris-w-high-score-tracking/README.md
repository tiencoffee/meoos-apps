# Tetris w/ high score tracking

A Pen created on CodePen.io. Original URL: [https://codepen.io/dutchbones/pen/MXXgMz](https://codepen.io/dutchbones/pen/MXXgMz).

Hope you have fun playing! Feature suggestions and improvements are very welcome! 

Browser version available here: https://dutchbones.github.io/tetris