# Unruly Tower

A Pen created on CodePen.io. Original URL: [https://codepen.io/johan-tirholm/pen/jZorRd](https://codepen.io/johan-tirholm/pen/jZorRd).

LEFT and RIGHT arrow keys to run, SPACEBAR to jump. Inspired by a bunch of SNES/Mega Drive/Genesis games. Levels similar to this was pretty common in platformers from that era to mix up the gameplay from the usual horizontal scrolling. Good luck! :)