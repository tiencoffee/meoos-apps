# Sweet Memory Game - HTML5, JS and SCSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/eliortabeka/pen/WwzEEg](https://codepen.io/eliortabeka/pen/WwzEEg).

#####Sweet Animated Memory Game