# Infinite Mine-Sweeper

A Pen created on CodePen.io. Original URL: [https://codepen.io/Jiminibob/pen/XaVLBQ](https://codepen.io/Jiminibob/pen/XaVLBQ).

It's mine-sweeper, but infinite... how far can you get?
