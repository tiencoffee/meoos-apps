/* Yes there is a bug if you click out of the tiles after going as X -- can I fix it? I don't know! */

/* Seems like there's an issue with :focus selector in Safari and FireFox. This could be Chrome not conforming - but I see some accessibility issues for multi-input device users. Will check back */

/* UPDATE
Thanks to Roman Komarov's post http://kizu.ru/en/blog/counters-and-stones/ I was able to get around the :focus turn base issue. This is working in Chrome and even playable in FF now. Still Safari issues though. */