# Solitaire

A Pen created on CodePen.io. Original URL: [https://codepen.io/PicturElements/pen/RVZOQr](https://codepen.io/PicturElements/pen/RVZOQr).

