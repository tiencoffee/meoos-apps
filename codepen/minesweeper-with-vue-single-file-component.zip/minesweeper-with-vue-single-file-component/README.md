# Minesweeper with Vue single file component

A Pen created on CodePen.io. Original URL: [https://codepen.io/HunorMarton/pen/LYGYMgV](https://codepen.io/HunorMarton/pen/LYGYMgV).

