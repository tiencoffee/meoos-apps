# 2048 Game with a bot

A Pen created on CodePen.io. Original URL: [https://codepen.io/FRADAR/pen/OJWvzPV](https://codepen.io/FRADAR/pen/OJWvzPV).

A 2048 game with a bot. Play it on google: https://elgoog.im/2048/