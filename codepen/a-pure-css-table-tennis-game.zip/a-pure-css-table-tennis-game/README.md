# A Pure CSS Table Tennis Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/ivorjetski/pen/mdzrLbW](https://codepen.io/ivorjetski/pen/mdzrLbW).

### 10 PRINT "Hello CSS Only Table Tennis"; <br>
### 20 GOTO 10<br>
<br>

- No images 
- No JavaScript 
- Only CSS 
- And a few HTML radio inputs :)<br>
<br>

This experiment aimed to test my CSS skills by exploring how closely I can mimic the appearance and functionality of a finished application.

It was loosely based on a memory of I'm Ping Pong King :) 

BTW I have no idea how to play table tennis, as you can probably tell.

How it was made:
https://youtu.be/MX_Y1jO_iIk

https://linktr.ee/ivorjetski for more

A full screen version can be found here: https://tinydesign.co.uk/css-10is