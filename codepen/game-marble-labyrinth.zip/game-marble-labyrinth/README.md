# [game] Marble labyrinth 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gthibaud/pen/zNwgmZ](https://codepen.io/Gthibaud/pen/zNwgmZ).

I wanted to make a little game with a simple gameplay :) if you have something to tell me about this pen, please do so in the comment section.