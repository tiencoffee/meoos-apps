# Bounce Da Ball

A Pen created on CodePen.io. Original URL: [https://codepen.io/FRADAR/pen/VwEvPdX](https://codepen.io/FRADAR/pen/VwEvPdX).

Bounce the ball on the paddle and pick your difficulty.