# Color Collision

A Pen created on CodePen.io. Original URL: [https://codepen.io/dev_loop/pen/gOYLbge](https://codepen.io/dev_loop/pen/gOYLbge).

Amazing things happen when a circle is colored and a logic is applied.
Github : https://github.com/devloop01/color-collision

css background from -> https://leaverou.github.io/css3patterns/
