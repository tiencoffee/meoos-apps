# Flappy Block

A Pen created on CodePen.io. Original URL: [https://codepen.io/mwooddesigns/pen/dMxNqe](https://codepen.io/mwooddesigns/pen/dMxNqe).

Practicing basic game physics by making a mediocre flappy bird-like game.