# 3D Obstacle Avoiding Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/ljf7/pen/vYVyOwM](https://codepen.io/ljf7/pen/vYVyOwM).

This is written by Ritza and I just copied it!