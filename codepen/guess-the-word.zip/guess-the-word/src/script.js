

let wordArray = ["JAWS", "CAT", "PANTS", "TABLE", "PICKLEBALL", "COMPUTER", "WINDOW", "BOOK", "HAIR", "LEAGUE", "LEGS", "KEYBOARD", "HANGMAN", "TELEVISION", "BINDER", "GUN", "LION", "DART", "SLEEP", "WEIRD", "HIPPO", "FIREWORKS", "WHITEBOARD", "PLANE", "TRAIN", "TRANSFER", "BOX", "DRAWING", "MOVIE", "FLICK", "RESTAURANT", "COUNTRY", "TREE", "LEAVES", "TEETH", "FLAG", "SPIDER", "PLANT", "CLOSET", "WELCOME", "APPLE", "ORANGE", "BANANA", "KIWI", "PINEAPPLE", "TABLET", "BOY", "GIRL", "CLOCK", "MONKEY", "JACKET", "SWEATSHIRT", "SHOES", "MEMO", "ALIEN", "FLY", "FEMUR", "GLOBE", "VIDEO", "ARM", "CHIPS", "ACTION", "MESSY", "SUCK", "PEONY", "PENCIL", "CHOCOLATE", "YOGURT", "FRIGID", "BEAST", "AFRICA", "ASIA", "AMERICA", "SPONGE", "PATTY", "DUCK", "DITCH", "CREAM", "POPCORN", "HEADPHONES", "FAT", "EUROPE", "AUSTRALIA", "ANTARCTICA", "MOTHER", "STICK", "DICTIONARY", "CHAIN", "GLASSES", "HUNDRED", "MOUNTAIN", "HILL", "ENERGY", "ROLLER", "WATCH", "TOILET", "MILK", "SEVEN", "SIX", "FIVE", "FOUR", "THREE", "TWO", "ONE", "ZERO", "EIGHT", "NINE", "TEN", "ONION", "DOMESTICATED", "HUMAN", "DOG", "PITA", "TACO", "BURRITO", "MEXICO", "HISPANIC", "RED", "ORANGE", "YELLOW", "GREEN", "BLUE", "PURPLE", "PINK", "BROWN", "BLACK", "PHONE", "HAND", "NOSE", "HEAD", "NECK", "FOOT", "DESK", "BATH", "SHOWER", "PAPER", "PANTHER", "NORTH", "EAST", "WEST", "SOUTH", "ALABAMA", "ALASKA", "ARIZONA", "ARKANSAS", "CALIFORNIA", "COLORADO", "CONNECTICUT", "DELAWARE", "FLORIDA", "GEORGIA", "HAWAII", "IDAHO", "ILLINIOS", "INDIANA", "IOWA", "KANSAS", "KENTUCY", "LOUISIANA", "MAINE", "MARYLAND", "MASSACHUSETTS", "MICHIGAN", "MINNESOTA", "MISSISSIPPI", "MISSOURI", "MONTANA", "NEBRASKA", "NEVADA", "OHIO", "OKLAHOMA", "OREGON", "PENNSYLVANIA", "TENNESSEE", "TEXAS", "UTAH", "VERMONT", "VIRGINIA", "WASHINGTON", "WISCONSIN", "WYOMING", "RUSSIA", "UKRAINE", "CHINA", "JAPAN", "THAILAND", "FRANCE", "SPAIN", "MEXICO", "MONEY", "UGLY", "SABER", "SPEAR", "JAVELIN", "SKY", "QUOTA", "QUOTE", "JAWS", "WATER", "MILK", "XRAY", "XYLOPHONE", "ELEPHANT", "BRAIDS", "LOCK", "MAP", "BRICK", "BONE", "ICE", "SPICE", "IRON", "DIAMONDS", "AMBER", "EMERALD", "CODE", "PACK", "DARK", "DAY", "NIGHT", "PNEUMONOULTRAMICROSCOPICSILICOVOLCANOCONIOSIS", "SUBDERMATOGLYPHIC", "INSOLENCE", "SEASHELL", "OCEAN", "STARFISH", "COD", "SALMON", "URCHIN", "BYTE", "BIT", "MATH", "SCIENCE", "ENGLISH", "FRENCH", "SPANISH", "HISTORY", "MEDIA", "HEALTH", "GYMNASTICS", "CONDITIONING", "DESKTOP", "PLANKTON", "SQUIRREL", "GOO", "BLEACHERS", "LOSE", "WIN", "CHOSEN", "FLOOR", "ARRAY", "RANDOM", "LIVES", "DANCE", "WRITE", "BIKE", "MOTORCYCLE", "UNICYCLE", "ALLY", "DISAGREE", "AGREE", "APPROVE", "TEACHER", "COLLEGE", "CONFLICT", "STORM", "APPRAISE", "CHORD", "TRADEMARK", "CUTLASS", "CRISP", "INCOME", "DANGER", "CHAOS", "REALM", "PRETEEN", "GALAXY", "TEMPER", "LIGAMENT", "EMPLOYEE", "WEALTH", "INQUISITION", "WETLANDS", "TINTING", "SAPPHIRE", "SICKLE", "LICHEN", "SWEAR", "HYPNOTHIZE", "BEER", "HABITAT", "EXCESS", "EXCESS", "SYSTEM", "DIVISION", "MAGNETIC", "FEIGN", "CHIP", "CONVICT", "EXAGGERATE", "JOINT", "HONEST", "TOOL", "EXCUSE", "LEGISLATION", "PORTRAIT", "REPORT", "THOUGHTFUL", "OCCASION", "REFEREE", "OVERALL", "VEGETATION", "EVOLUTION", "GATE", "BUTTOCKS", "SERIES", "KETTLE", "CROP", "ELEPHANT", "GRADIENT", "FIGURE", "RESEARCH", "SECRETARY", "PRESIDENT", "PAIN", "DATE", "POCKET", "FUNCTION", "OPERATIONAL", "TENT", "PREDICTION", "CAGE", "FAVORABLE", "CONFESSION", "ORDINARY", "APPEAL", "SNACK", "KNOWLEDGE", "RABBIT", "ARTICULATE", "REVIVAL", "CHILDISH", "DEADLY", "POPULATION", "PRODUCER", "GUERRILLA", "EMBOX", "GLOVE", "FABRICATE", "BRUSH", "PRISONER", "FORMAL", "ANNUAL", "BULB", "SUPERCALIFRAGILISTICEXPIALIDOCIOUS"];
let chosenWord = wordArray[Math.floor(Math.random() * wordArray.length)]

console.log(chosenWord)
let lives = 10
let guessdisplay = document.getElementById("GuessDisplay")
let livesdisplay = document.getElementById("livesdisplay")
let worddisplay = document.getElementById("WordDisplay")
while (worddisplay.innerHTML.length < chosenWord.length) {
  worddisplay.innerHTML = worddisplay.innerHTML + "-"
}

function checkforletter(letter) {
if (lives !== 0 && lives !== "win") {
  
    livesdisplay.innerHTML = "You have " + lives + " lives"

let checkforguess = guessdisplay.innerHTML.includes(letter)
  if (checkforguess == false) {
    let node = document.createTextNode(" " + letter) 
    guessdisplay.appendChild(node)
  if (chosenWord.includes(letter)) {
for (let i = 0; i < chosenWord.length; i++) {
  if (chosenWord.charAt(i) == letter) {
 
  let a = worddisplay.innerHTML.split("");
  a[i] = letter;
  worddisplay.innerHTML = a.join("");
if (worddisplay.innerHTML == chosenWord) {
  livesdisplay.innerHTML = "You win! Press reset to play again!"
  lives = "win"
}
  }
  
}
}
  else {
    lives = lives - 1
    
if (lives == 0) {
      livesdisplay.innerHTML = "Game over! The word was " + chosenWord + ". Press reset to try again!"
    } else {
livesdisplay.innerHTML = "You have " + lives + " lives"
    }
    
  }
  }
  else {
    livesdisplay.innerHTML = "Already guessed!"
   if (lives == 0) {
      livesdisplay.innerHTML = "Game over! The word was " + chosenWord + ". Press reset to try again!"
     if (lives == "win") {
  livesdisplay.innerHTML = "You win! Press reset to play again!"
    }
  }
}

}
}





function reset() {
chosenWord = wordArray[Math.floor(Math.random() * wordArray.length)]
console.log(chosenWord);
lives = 10;
guessdisplay.innerHTML = ""
worddisplay.innerHTML = ""
while (worddisplay.innerHTML.length < chosenWord.length) {
  worddisplay.innerHTML = worddisplay.innerHTML + "-"
}
livesdisplay.innerHTML = "You have " + lives + " lives"
}

