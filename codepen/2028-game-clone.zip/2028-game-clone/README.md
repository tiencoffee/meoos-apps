# 2028 Game Clone

A Pen created on CodePen.io. Original URL: [https://codepen.io/Vishal4225/pen/XWxxoYR](https://codepen.io/Vishal4225/pen/XWxxoYR).

A clone of the popular game "2028" with similar gameplay mechanics and a simple user interface.