# Eternal Mine

A Pen created on CodePen.io. Original URL: [https://codepen.io/gnsksz/pen/LwOWmR](https://codepen.io/gnsksz/pen/LwOWmR).

You can play unlimited size minesweeper until your broser runs out of memory.