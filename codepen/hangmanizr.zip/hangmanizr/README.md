# Hangmanizr 

A Pen created on CodePen.io. Original URL: [https://codepen.io/mburakerman/pen/eBerPG](https://codepen.io/mburakerman/pen/eBerPG).

Quick Hangman Game built with React.js

https://mburakerman.github.io/hangmanizr/