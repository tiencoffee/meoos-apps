# Old School Racing Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/johan-tirholm/pen/PGYExJ](https://codepen.io/johan-tirholm/pen/PGYExJ).

Use  arrow keys to drive. The basics of a classic style racing game. Inspired by games like "Out Run"  and "F1 Race".