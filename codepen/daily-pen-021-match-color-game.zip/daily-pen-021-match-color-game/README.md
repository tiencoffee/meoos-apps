# Daily Pen #021: Match Color Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/EduardoLopes/pen/KKZGRZ](https://codepen.io/EduardoLopes/pen/KKZGRZ).

- Click in the colors that match
- lose -200 if don't match
- win (matching blocks * 10) if match
- The game it's infinite, have no end.

I'm very happy with this game, i learned a lot of news things. I want to make more simples games like this to learn more. 

I spend some more time making this game than the [another one](http://codepen.io/EduardoLopes/pen/IJnAr), i needed to figure out how to make a pathfinder, and before i spent a lot of time trying to do by 'brutal force'. I think was 3 days making this game.

Enjoy. :D

Update: Clean up the code a little bit and add some comments.
Update 2: Fix a bug