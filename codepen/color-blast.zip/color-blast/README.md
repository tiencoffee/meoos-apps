# Color Blast!

A Pen created on CodePen.io. Original URL: [https://codepen.io/natewiley/pen/ExEoeZ](https://codepen.io/natewiley/pen/ExEoeZ).

Use the `Left` and `Right` Arrows or `A` and `D` keys to move, `Spacebar` to shoot.

Game starts right away, looks best in [full mode.](http://codepen.io/natewiley/full/EGyiF) 

Hope you like it! ;)