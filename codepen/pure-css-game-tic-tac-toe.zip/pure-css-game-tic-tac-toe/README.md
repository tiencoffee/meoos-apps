# Pure CSS Game Tic-Tac-Toe 

A Pen created on CodePen.io. Original URL: [https://codepen.io/jerrylow/pen/XVVBzv](https://codepen.io/jerrylow/pen/XVVBzv).

Pure CSS game Tic-Tac-Toe. This is a turned based version. Just trying to push some limits here.  Yes there is a bug if you click out of the tiles after going as X -- can I fix it? I don't know!