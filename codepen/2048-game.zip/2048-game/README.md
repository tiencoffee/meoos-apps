# 2048 Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/miftah0908/pen/MWqMRZa](https://codepen.io/miftah0908/pen/MWqMRZa).

2048 SIMPLE GAME WITH HTML, CSS & JAVA SCRIPT PROGRAMMING LANGUAGES