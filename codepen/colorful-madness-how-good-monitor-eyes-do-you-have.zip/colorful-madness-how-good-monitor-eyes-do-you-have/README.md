# 🎨 Colorful madness – How good monitor / eyes do you have? 👀

A Pen created on CodePen.io. Original URL: [https://codepen.io/jukben/pen/MEPpyV](https://codepen.io/jukben/pen/MEPpyV).

A little game based on the "eye test" idea. I hope you'll like it. 

Your ❤️ will be appreciated.