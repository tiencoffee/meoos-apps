# Space Hack

A Pen created on CodePen.io. Original URL: [https://codepen.io/Xanmia/pen/kVVJYO](https://codepen.io/Xanmia/pen/kVVJYO).

A rough first attempt at a threejs game. Only works in Chrome and Firefox.  Concept from Buck Rogers: Planet of Zoom.