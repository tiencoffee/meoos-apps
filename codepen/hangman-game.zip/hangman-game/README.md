# Hangman game

A Pen created on CodePen.io. Original URL: [https://codepen.io/takaneichinose/pen/yVXYRo](https://codepen.io/takaneichinose/pen/yVXYRo).

A simple hangman game written in Javascript (Without any libraries nor pre-processors). Try to guess the missing word, but while guessing, don't look at the Javascript source code. It's cheating!