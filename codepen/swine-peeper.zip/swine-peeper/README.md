# Swine Peeper

A Pen created on CodePen.io. Original URL: [https://codepen.io/tipvfl/pen/qdpWaY](https://codepen.io/tipvfl/pen/qdpWaY).

Swine Peeper is a cute pig-themed version of Minesweeper!

It works perfectly across phones, tablets, and computers due to its responsive design and programmatic graphics created entirely in CSS/HTML that scale to any resolution. 

It is now available as an Android app on Google Play,
https://play.google.com/store/apps/details?id=com.ionicframework.myapp630896