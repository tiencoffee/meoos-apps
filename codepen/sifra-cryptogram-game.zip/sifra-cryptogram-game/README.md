# Sifr - A Cryptogram Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/jjmartucci/pen/pvQzOg](https://codepen.io/jjmartucci/pen/pvQzOg).

A cryptogram / cryptoquiz game that I wrote and released for iOS as a personal proof-of-concept when I was getting in to web development. It hasn't been in the app store in a long time, but I thought someone might like to play it here.

If you can beat any (or all) of the master levels, post a comment and I'll heart it a million times. 