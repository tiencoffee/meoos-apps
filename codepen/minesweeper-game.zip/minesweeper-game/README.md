# Minesweeper game

A Pen created on CodePen.io. Original URL: [https://codepen.io/HectorVilas/pen/qBYorzQ](https://codepen.io/HectorVilas/pen/qBYorzQ).

This is a game I made by myself back in April 2022 (initial commit, 2 months after I started learning frontend). The code is bad, I know, but it's playable!

Check my GitHub profile for other projects:
https://github.com/HectorVilas