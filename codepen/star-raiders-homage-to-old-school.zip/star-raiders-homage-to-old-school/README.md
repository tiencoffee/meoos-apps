# Star-Raiders : homage to old school

A Pen created on CodePen.io. Original URL: [https://codepen.io/Bolloxim/pen/jOZGbM](https://codepen.io/Bolloxim/pen/jOZGbM).

This is the frame work game for star-raiders remake in pure html 5 canvas.  Oh yes we could make this in webGL but whats the fun of that. More interesting to see what we can render in 3D without using a 3D rendering api. 

The game is 100% procedural and javascript including the audio

controls are based on touch screen as well for ipads etc, keyboard short cuts will be available however mapping to the originals. 

version 0.1  Forked Galactic Scanner and added buttons hud items. This means that AI works for tokens on scanner and we can populate locals with enemys now. 

version 0.2 Long Range Scanner. This gives enemies in local space and a means to align and target those enemies

version 0.3 started to break files apart

version 0.4 started to bring in pov 3d with overlays.  Damn ship controls suck though. Needs new design for mouse

version 0.5 fixed long range scanner added transitions

version 0.6 changed controls. cleaned up scanners changed fonts to be more star-raiders. Added star-field. added warp. more energy management.  starting to get fun!

version 0.7 can now shoot. can now shoot asteriods.. can now fragment the asteriods upto 4 times..  lots o fun

version 0.8 so NMEs will jump into sectors red alerts sounds and play can move around the galaxy consuming their precious energy

version 0.9 NMEs are rendered. targeting computer tracking works. cant shoot them or vice-versa. no ai yet.. just vector'd pathing.

version 0.95 starbase, basestar both in.  No AI still. Text plotters with information displayed. Sparser field of stars, but stars pan with motion. lots of bugs fixed

version 0.96 clocks counting down starbase destruction.  Started work on AI combat

so version 0.95 BETA.

we have a global database ranking system
we have pokey emulated audio but really its webaudio api

TODO: Code Packaging its got messy in the last week cramming in titles and ranks etc... needs some modulizing

Profiler added.
Created a cool JS function that if you add profile(myFunc) it auto adds profile information