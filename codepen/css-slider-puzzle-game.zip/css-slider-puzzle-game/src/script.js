// JS is for web, I build email.

// Follow on twitter for more CSS and email hacks @M_J_Robbins
// font-size:1vmin; messes with applemail's poor little brain and slows everything down so put a fixed size in here for email - 8px works well.