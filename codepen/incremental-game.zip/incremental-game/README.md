# Incremental Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/samuelbeard/pen/AgJQYv](https://codepen.io/samuelbeard/pen/AgJQYv).

A game built in Javascript that increments clicks.