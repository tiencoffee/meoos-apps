# Bubble Sorting Island Adventure

A Pen created on CodePen.io. Original URL: [https://codepen.io/ripter/pen/qwyMXr](https://codepen.io/ripter/pen/qwyMXr).

Sort the island back together with the power of bubble sort! Click on an island to swap it with the island above it! That's it! With that knowledge, you can save the world!

_Created for the [April 2019 CodePen Challenge](https://codepen.io/challenges/2019/April)_