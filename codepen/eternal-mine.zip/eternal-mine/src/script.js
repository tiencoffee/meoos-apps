const CLICK_MOVE_THRESHOLD = 15;
const TOUCH_OPEN_FLAG_THRESHOLD = 300;
const MARGIN = 0;

const BIT_MINE = 16;
const BIT_OPEN = 32;
const BIT_FLAG = 64;

const CELL_SIZE = 32;
const CHUNK_SIZE_SHIFT = 5;
const CHUNK_SIZE = 1 << CHUNK_SIZE_SHIFT;
const NUM_COLORS = ["#000", "#00a", "#0a0", "#a00", "#226", "#622", "#262", "#222", "#444"];

class Dragger {
  constructor(canvas) {
    this.x = 0;
    this.y = 0;
    this.prevX = -1;
    this.prevY = -1;
    this.travel = 0;
    this.touchid = -1;
    this.onmove = null;
    this.onclick = null;
    this.canvas = canvas;
    canvas.addEventListener("mousedown", event => this.handleDown(event.clientX, event.clientY, event.buttons));
    canvas.addEventListener("mouseup", this.handleMouseUp.bind(this));
    canvas.addEventListener("mousemove", event => this.handleMove(event.clientX, event.clientY, event.buttons));
    canvas.addEventListener("touchstart", this.handleTouchStart.bind(this), { passive: false });
    canvas.addEventListener("touchend", this.handleTouchEnd.bind(this), { passive: false });
    canvas.addEventListener("touchmove", this.handleTouchMove.bind(this), { passive: false });
  }
  handleTouchStart(evt) {
    evt.preventDefault();
    if (this.touchid == -1) {
      const t = evt.targetTouches[0];
      const b = evt.targetTouches.length;
      this.touchid = t.identifier;
      this.touchStartTime = new Date().getTime();
      this.handleDown(t.clientX, t.clientY, b);
    }
  }
  handleTouchEnd(evt) {
    evt.preventDefault();
    if (this.touchid == -1) return;
    let t = evt.changedTouches[0];
    if (t.identifier == this.touchid) {
      const tm = new Date().getTime() - this.touchStartTime;
      const b = tm > TOUCH_OPEN_FLAG_THRESHOLD ? 2 : 1;
      this.touchid = -1;
      this.handleUp(t.clientX, t.clientY, b);
    }
  }
  handleTouchMove(evt) {
    evt.preventDefault();
    if (this.touchid == -1) return;
    let t = evt.changedTouches[0];
    if (t.identifier == this.touchid) {
      const b = evt.targetTouches.length;
      this.handleMove(t.clientX, t.clientY, b);
    }
  }
  handleMouseUp(evt) {
    this.handleUp(evt.clientX, evt.clientY, this.btns);
  }
  handleDown(x, y, buttons) {
    this.prevX = x;
    this.prevY = y;
    this.travel = 0;
    this.btns = buttons;
  }
  handleUp(x, y, buttons) {
    this.prevX = -1;
    this.prevY = -1;
    if (this.travel < CLICK_MOVE_THRESHOLD) {
      if (this.onclick) {
        const rect = this.canvas.getBoundingClientRect();
        const cx = x - rect.x - this.x - MARGIN;
        const cy = y - rect.y - this.y - MARGIN;
        this.onclick(cx, cy, buttons);
      }
    }
  }
  handleMove(x, y, buttons) {
    if (buttons == 0) return;
    const deltaX = x - this.prevX;
    const deltaY = y - this.prevY;

    this.travel += Math.abs(deltaX) + Math.abs(deltaY);
    this.prevX = x;
    this.prevY = y;

    if (this.travel > CLICK_MOVE_THRESHOLD) {
      this.x += deltaX;
      this.y += deltaY;
      if (this.onmove != null) {
        this.onmove(this);
      }
    }
  }
}

class View {
  constructor(canvas, header) {
    this.canvas = canvas;
    this.header = header;
    this.ctx = canvas.getContext("2d");

    this.dragger = new Dragger(canvas);
    this.field = new Field();
    this.isDirty = true;

    this.registerEvents();
    this.sprites = this.makeSprites();
    this.resize();

    const drawloop = () => {
      if (this.isDirty) {
        this.isDirty = false;
        this.draw();
      }
      window.requestAnimationFrame(drawloop);
    }
    window.requestAnimationFrame(drawloop);
  }
  makeSprites() {
    const sprites = {};
    const offscreen = new OffscreenCanvas(CELL_SIZE, CELL_SIZE);
    const ctx = offscreen.getContext("2d");
    ctx.font = "20px fantasy";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.strokeStyle = "gray";
    ctx.lineWidth = 1;
    const hs = CELL_SIZE / 2; // half size of cell
    const closeGradient = ctx.createRadialGradient(hs, hs, 0, hs, hs, CELL_SIZE);
    closeGradient.addColorStop(0, "#dfdfdf");
    closeGradient.addColorStop(0.7, "#d3d3d5");
    const openGradient = ctx.createRadialGradient(hs, hs, 0, hs, hs, CELL_SIZE);
    openGradient.addColorStop(0, "#ffffff");
    openGradient.addColorStop(0.7, "#f0f0ff");
    ctx.fillStyle = closeGradient;
    ctx.fillRect(0, 0, CELL_SIZE, CELL_SIZE);
    ctx.strokeRect(0, 0, CELL_SIZE, CELL_SIZE);
    sprites[0] = offscreen.transferToImageBitmap();
    ctx.drawImage(sprites[0], 0, 0);
    ctx.fillText("🚩", hs, hs);
    sprites[BIT_FLAG] = offscreen.transferToImageBitmap();
    ctx.fillStyle = openGradient;
    ctx.fillRect(0, 0, CELL_SIZE, CELL_SIZE);
    ctx.strokeRect(0, 0, CELL_SIZE, CELL_SIZE);
    sprites[BIT_OPEN] = offscreen.transferToImageBitmap();
    for (let i = 1; i < 9; i++) {
      ctx.drawImage(sprites[BIT_OPEN], 0, 0);
      ctx.fillStyle = NUM_COLORS[i];
      ctx.fillText(i, hs, hs);
      sprites[BIT_OPEN + i] = offscreen.transferToImageBitmap();
      sprites[BIT_FLAG + i] = sprites[BIT_FLAG];
      sprites[i] = sprites[0];
    }
    ctx.fillStyle = "brown";
    ctx.fillRect(0, 0, CELL_SIZE, CELL_SIZE);
    ctx.fillText("💣", hs, hs);
    sprites[BIT_OPEN + BIT_MINE] = offscreen.transferToImageBitmap();
    sprites[BIT_FLAG + BIT_MINE] = sprites[BIT_FLAG];
    sprites[BIT_MINE] = sprites[0];
    return sprites;
  }
  registerEvents() {
    window.addEventListener("resize", () => this.resize());
    this.dragger.onmove = () => {
      if (this.header != null) {
        this.header.classList.add('hidden');
        this.header = null;
      }
      this.isDirty = true;
    };
    this.dragger.onclick = this.onclick.bind(this);
  }
  onclick(x, y, buttons) {
    let i = Math.floor(y / CELL_SIZE);
    let j = Math.floor(x / CELL_SIZE);
    if (buttons == 1) {
      this.field.open(i, j);
    } else if (buttons == 2) {
      this.field.flag(i, j);
    }
    this.isDirty = true;
  }
  resize() {
    this.width = this.canvas.width = window.innerWidth;
    this.height = this.canvas.height = window.innerHeight;
    this.isDirty = true;
  }
  draw() {
    const ctx = this.ctx;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, this.width, this.height);
    const [l, t, w, h] = coverRect(this.dragger.x, this.dragger.y, this.width, this.height, CELL_SIZE);
    ctx.translate(this.dragger.x, this.dragger.y);
    for (let i = 0; i <= h; i++) {
      for (let j = 0; j <= w; j++) {
        const cj = j - l;
        const ci = i - t;
        const c = this.field.readAt(ci, cj);
        ctx.drawImage(this.sprites[c], cj * CELL_SIZE, ci * CELL_SIZE);
      }
    }
    ctx.restore();
  }
}

class Field {
  constructor(seed = -1) {
    this.seed = seed != -1 ? seed : parseInt(Math.random() * 2147483647);
    this.chunks = {};
    this.memorySize = 0;
    this.score = 0;
    this.version = 0;
    this.onChange = null;
  }
  getKey(i, j) {
    return `${i},${j}`;
  }
  readAt(i, j) {
    const { chunk, idx } = this._getChunkAccessor(i, j);
    return chunk[idx];
  }
  click(x, y, b) {
    if (b == 1) this.open(x, y);
    else this.flag(x, y);
  }
  open(i, j, isSubCall = false) {
    const { chunk, idx } = this._getChunkAccessor(i, j, true);
    if (chunk == undefined) return;
    let v = chunk[idx];
    if (v & BIT_OPEN || v & BIT_FLAG) return;
    chunk[idx] |= BIT_OPEN;
    if (v == 0) {
      this._enumNeighborIndex(i, j).forEach(v => this.open(v[0], v[1], true));
    }
    if (!isSubCall) {
      this.isChanged = true;
      this.score += (v & 15);
    }
  }
  flag(i, j) {
    const { chunk, idx } = this._getChunkAccessor(i, j, false);
    if (chunk == undefined) return;
    let v = chunk[idx];
    if (v & BIT_OPEN) return;
    chunk[idx] ^= BIT_FLAG;
  }
  _getChunkAccessor(i, j, makeNewChunk = true) {
    const ci = i >> CHUNK_SIZE_SHIFT;
    const cj = j >> CHUNK_SIZE_SHIFT;
    const y = i - ci * CHUNK_SIZE;
    const x = j - cj * CHUNK_SIZE;
    const idx = x + y * CHUNK_SIZE;

    const key = this.getKey(ci, cj);
    let chunk = this.chunks[key];
    if (chunk == undefined && makeNewChunk) {
      chunk = this._makeChunk(ci, cj);
    }
    return { chunk, idx };
  }
  _makeChunk(i, j) {
    const chunk = new Uint8Array(CHUNK_SIZE * CHUNK_SIZE);
    const opened = [];
    for (let y = 0, idx = 0; y < CHUNK_SIZE; y++) {
      for (let x = 0; x < CHUNK_SIZE; x++ , idx++) {
        let ci = i * CHUNK_SIZE + y;
        let cj = j * CHUNK_SIZE + x;
        if (this._isMine(ci, cj)) {
          chunk[idx] = BIT_MINE;
        } else {
          chunk[idx] = this._enumNeighborIndex(ci, cj).filter(v => this._isMine(v[0], v[1])).length;
        }
      }
    }
    this.chunks[this.getKey(i, j)] = chunk;
    this.memorySize += CHUNK_SIZE * CHUNK_SIZE; // byte
    return chunk;
  }
  _enumNeighborIndex(i, j) {
    const r = [];
    for (let oi = -1; oi < 2; oi++) {
      for (let oj = -1; oj < 2; oj++) {
        if (oi != 0 || oj != 0) {
          r.push([i + oi, j + oj]);
        }
      }
    }
    return r;
  }
  _isMine(i, j) {
    let v = this.seed ^ (i * 31) ^ (j * 9576407);
    v ^= v << 13; v ^= v >>> 17; v ^= v << 5;
    v = (v & 0x7fffff) % 1000;
    return v < this._calcDifficulty(i, j) * 1000;
  }
  _calcDifficulty(i, j) {
    const min = 8 / 81;
    const max = 99 / 480;
    const maxd = 500;
    const d = Math.max(Math.abs(i), Math.abs(j));
    return (d > maxd ? max : min + d / maxd * (max - min));
  }
}
function coverRect(x, y, w, h, size) {
  const [left, width] = coverRange(x, w, size);
  const [top, height] = coverRange(y, h, size);
  return [left, top, width, height];
}
function coverRange(pos, len, size) {
  const p = Math.ceil(pos / size);
  const r = pos - p * size;
  const l = Math.floor((len - r) / size);
  return [p, l];
}
const v = new View(document.querySelector("canvas"), document.querySelector("header"));