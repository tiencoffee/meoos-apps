# Game_Tetris

A Pen created on CodePen.io. Original URL: [https://codepen.io/nguyencaotai1969/pen/KKNwRQP](https://codepen.io/nguyencaotai1969/pen/KKNwRQP).

