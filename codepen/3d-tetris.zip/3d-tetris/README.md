# 3D Tetris

A Pen created on CodePen.io. Original URL: [https://codepen.io/FRADAR/pen/wvJgwZG](https://codepen.io/FRADAR/pen/wvJgwZG).

3D Tetris made using css3 and jquery. [A] and [S] to rotate blocks and arrow keys to move left and right. Google Chrome and Firefox are only supported. Sorry ☹.