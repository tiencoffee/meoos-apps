# Memory cards

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexlead/pen/dyMebea](https://codepen.io/alexlead/pen/dyMebea).

JS games - memory cards