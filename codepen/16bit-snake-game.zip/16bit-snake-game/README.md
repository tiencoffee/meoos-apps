# 16bit Snake Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/thisisbetkowski/pen/QoPQBy](https://codepen.io/thisisbetkowski/pen/QoPQBy).

