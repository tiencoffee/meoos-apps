# CSS/HTML Platform Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/nathantaylor/pen/KaLvXw](https://codepen.io/nathantaylor/pen/KaLvXw).

Creativity is born from limitations.  Its fun to try and create something unique within the constraint of only using CSS/HTML. 