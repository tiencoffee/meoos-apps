# Guess The Word!

A Pen created on CodePen.io. Original URL: [https://codepen.io/kreamdagoat/pen/oNaovWm](https://codepen.io/kreamdagoat/pen/oNaovWm).

hangman
Also if you want to add more words to the hangman, comment your suggestion