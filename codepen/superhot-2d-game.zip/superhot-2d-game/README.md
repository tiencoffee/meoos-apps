# SUPERHOT 2D GAME

A Pen created on CodePen.io. Original URL: [https://codepen.io/benjaminmiles/pen/PNoXdQ](https://codepen.io/benjaminmiles/pen/PNoXdQ).

A quick weekend prototype to try and replicate the SUPERHOT time warp effect. Your movement directly affects the speed of time. Move quickly and the game ascends to real time. Slow down and the game does the same.

Move with your arrow keys. Shoot with the spacebar. Keyboard only.

Based on and inspired by:
https://superhotgame.com

Built using:
http://phaser.io

Learn more:
http://www.benjaminmiles.com/blog/2016/2/29/superhot-2d