# CubeOne

A Pen created on CodePen.io. Original URL: [https://codepen.io/kunukn/pen/BLGEmV](https://codepen.io/kunukn/pen/BLGEmV).

Can yo solve the puzzle? all the front cubes must have the same the same face and the same rotation. Rotate the cubes by swiping with finger/mouse or using arrow/wasdqe keys when the cube is focused. You can use the rotate button to change the view. Tested with Chrome, Safari, Firefox (glithy), Edge and IE11 is buggy and is not currently supported. Source code available at github.com/kunukn/cube-one. The svg image is creative commons licensed.