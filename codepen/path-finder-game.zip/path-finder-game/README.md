# Path Finder Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/blazicke/pen/MEvZRR](https://codepen.io/blazicke/pen/MEvZRR).

A simple svg game: given the first dot, you have to connect it to the nearest yellow dot, and so on!