# JavaScript Hangman game

A Pen created on CodePen.io. Original URL: [https://codepen.io/cathydutton/pen/JjpxMm](https://codepen.io/cathydutton/pen/JjpxMm).

A JavaScript Hangman game with canvas animatoin.