# The Memory Games

A Pen created on CodePen.io. Original URL: [https://codepen.io/thinker3197/pen/BmxyOp](https://codepen.io/thinker3197/pen/BmxyOp).

Simple match the pairs game built in ReactJs