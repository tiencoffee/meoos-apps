# guess the number between 1 and 1000

A Pen created on CodePen.io. Original URL: [https://codepen.io/Ahmedeid67/pen/VwEajgz](https://codepen.io/Ahmedeid67/pen/VwEajgz).

This is a simple game guess the number between 1 and 1000