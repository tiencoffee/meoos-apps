# CSS Slider Puzzle Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/M_J_Robbins/pen/VeNWQQ](https://codepen.io/M_J_Robbins/pen/VeNWQQ).

Classic slider puzzle game, built with 51 radio buttons and no JS :)