# MATHEMAT1CS

A Pen created on CodePen.io. Original URL: [https://codepen.io/interaminense/pen/KgdZoM](https://codepen.io/interaminense/pen/KgdZoM).

This mini game is designed to enhance the mind of those who practice the mathematical operations. It is simple to play and try to beat your own record