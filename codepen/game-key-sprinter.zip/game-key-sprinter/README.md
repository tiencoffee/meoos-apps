# [game] Key Sprinter

A Pen created on CodePen.io. Original URL: [https://codepen.io/Gthibaud/pen/eLOYem](https://codepen.io/Gthibaud/pen/eLOYem).

Challenge someone else to a race ! :)
share both one keyboard to compete with each other !

player 1 should be on the left side of the keyboard and player 2 on the right side

Press the right key to move forward, the quicker you type, the quicker your player moves.
Made with [Diorama](https://github.com/gtibo/diorama)

[Luis quintana](https://github.com/plissken2013es) made a [multiplayer version](https://js13kgames.com/entries/key-sprinter-13k) on js13kgames