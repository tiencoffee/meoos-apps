# The Invisible Lizard Hunter Game. | A 2d Shooter Game.

A Pen created on CodePen.io. Original URL: [https://codepen.io/FRADAR/pen/ZEeYKdK](https://codepen.io/FRADAR/pen/ZEeYKdK).

Catch and kill all the camouflaging lizards! Use WASD to move and click to shoot. Don't let the lizards come to you! They decrease your health everytime they touch you. Once you kill a lizard, you get more bullets that you can use. The more bullets you get from killing the lizards, the more your health increases. You cannot move or shoot through black. If you are near a camouflaged lizard, the music will grow louder. (The music can be loud sometimes). The health bar is at the top of the screen. If you want to increase the difficulty, change line 43 (in the javascript window) from 30 to how many ever lizards you want on the map.

Also, you have 60 bullets to kill all 30 lizards.

READ:  _Use your cursor to aim at the lizards_ 

For best results,  play this game in debug mode.

_P.S_ The game world is auto generated


_Game over screen and win screen is not finished_