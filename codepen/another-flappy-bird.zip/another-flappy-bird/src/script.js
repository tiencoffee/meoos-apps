const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const scoreLabel = document.getElementById("score");
const newGame=document.getElementById('new-game')
const againButton = document.getElementById('again');


// fullscreen
canvas.width = innerWidth;
canvas.height = innerHeight;

// event listeners
canvas.addEventListener('mousedown',(e) => {
  if(bird){
    bird.upForce=10;
    bird.downForce=0.5;
    flapping=true;
  }
})
window.addEventListener('resize',()=>{
  canvas.width=innerWidth;
  canvas.height=innerHeight;
})
againButton.addEventListener('click', () => {
  newGame.style.display = "none";
  bird.y = 120;
  pipes=[];
  score=0;
  scoreLabel.innerText="SCORE: 0";
  playing=true;
  pipes.push(new Pipe());
  spawn = setInterval(() =>{
  pipes.push(new Pipe());
},3000);
  animate();
})

// globals
let bird;
let pipes = [];
let hills = [];
let trees = [];
let score = 0;
let playing = true;
let flapping = false;

class Bird {
  constructor(){
    this.x = 120;
    this.y = canvas.height/2;
    this.gravity = 0.5;
    this.upForce = 0;
    this.downForce = 0.5;
    this.w = 25;
    this.f=0;
  }
  draw(){
    //body
    ctx.fillStyle='yellow';
    ctx.beginPath();
    ctx.ellipse(this.x,this.y,this.w,this.w-4,0,0,Math.PI*2);
    ctx.fill();
    // beak
    ctx.beginPath();
    ctx.moveTo(this.x+35, this.y);
    ctx.lineTo(this.x+20, this.y-7);
    ctx.lineTo(this.x+20, this.y+7);
    ctx.lineTo(this.x+35, this.y);
    ctx.closePath();
    ctx.fill();
    // eye
    ctx.fillStyle='black';
    ctx.beginPath();
    ctx.arc(this.x+12, this.y-10,4,0,Math.PI*2);
    ctx.fill();
    // wing
    ctx.fillStyle='orange';
    ctx.beginPath();
    ctx.ellipse(this.x-10,this.y+this.f*100+3,this.w+5,this.w/4,-this.f*3,Math.PI*2,0);
    ctx.fill();
  }
  update(){
    this.y += this.downForce + this.gravity - this.upForce;
    this.upForce--;
    this.downForce+=0.05;
    if(this.upForce<0) this.upForce=0;
    if(this.y>canvas.height) {
      playing=false;
      newGame.style.display="block";
      clearInterval(spawn);
    }
    if(flapping){
      this.f += 0.05;
      if(this.f>0.2) {
        this.f = 0;
        flapping = false;
      } 
    }
  }
}

class Hill{
  constructor(x){
    this.w = Math.random()*100 + 100;
    this.y = canvas.height*0.8;
    this.x = x;
    this.alive = true;
  }
  draw(){
    ctx.fillStyle='brown';
    ctx.beginPath();
    ctx.arc(this.x,this.y,this.w,0,Math.PI,true);
    ctx.fill();
  }
  update(){
    this.x -= 0.5;
    if(this.x + this.w < 0) {
      this.alive=false;
    }
  }
}

class Tree{
  constructor(x){
    this.x=x;
    this.y=canvas.height*0.8;
    this.h=Math.random()*50 + 30;
    this.r=Math.random()*10 + 14;
    this.alive = true;
  }
  draw(){
    ctx.fillStyle = '#540';
    ctx.fillRect(this.x,this.y - this.h,10,this.h);
    ctx.fillStyle = '#0a0';
    ctx.beginPath(0);
    ctx.arc(this.x+5,this.y-this.h,this.r,0,Math.PI*2);
    ctx.fill();
  }
  update(){
    this.x -= 1;
    if(this.x+20 < 0){
      this.alive = false;
    }
  }
}

class Pipe{
  constructor(){
    this.x = canvas.width;
    this.h = Math.random()*canvas.height*0.6+canvas.height*.1;
    this.y = canvas.height-this.h;
    this.w = 100;
    this.alive = true;
  }
  draw(){
    ctx.fillStyle = 'green';
    ctx.fillRect(this.x+8,this.y,this.w-16,this.h);
    ctx.fillRect(this.x,canvas.height-this.h,this.w,20);
    ctx.fillRect(this.x+8,0,this.w-16,this.y-120);
    ctx.fillRect(this.x,canvas.height-this.h-140,this.w,20)
  }
  update(){
    this.x -=3;
    if(this.x+this.w<0){
      this.alive = false;
      score+=10;
      scoreLabel.innerText = "SCORE: " + score;
    }
  }
}

// spawn pipes
let spawn = setInterval(() =>{
  pipes.push(new Pipe());
},3000);
pipes.push(new Pipe());

function init(){
  bird = new Bird();
  let cx=0;
  for(let i = 0; i<10; i++){
    const hill = new Hill(cx);
    hills.push(hill);
    cx += hill.w + Math.random()*100;
  }
  cx=Math.random()*20;
  while(cx < canvas.width){
    const tree = new Tree(cx);
    trees.push(tree);
    cx += Math.random()*20 + 20;
  }
}


function animate(){
  ctx.fillStyle = 'lightblue';
  ctx.fillRect(0,0,canvas.width,canvas.height*.8);
  ctx.fillStyle='yellow';
  ctx.beginPath();
  ctx.arc(canvas.width*0.8,canvas.height*0.2,50,0,Math.PI*2);
  ctx.fill();
  ctx.fillStyle = 'lightgreen';
  ctx.fillRect(0,canvas.height*.8,canvas.width,canvas.height*.2);
  hills.forEach((hill,index) =>{
    hill.draw();
    hill.update();
    if(!hill.alive){
      hills.splice(index,1);
      hills.push(new Hill(canvas.width+100));
    }
  });
  trees.forEach((tree, index) =>{
    tree.draw();
    tree.update();
    if(!tree.alive){
      trees.splice(index,1);
    }
  });
  if(Math.random()>0.95){
    trees.push(new Tree(canvas.width + 20));
  }
  bird.draw();
  bird.update();
  pipes.forEach((pipe,index) => {
    pipe.draw();
    pipe.update();
    if(!pipe.alive){
      pipes.splice(index,1);
    }
  });
  if(collided()) {
    playing=false;
    newGame.style.display="block";
    clearInterval(spawn);
  }
  
  if(playing) requestAnimationFrame(animate);
}

function collided(){
  let col = false;
  pipes.forEach((pipe,index) => {
    if(bird.x + bird.w > pipe.x && bird.x - bird.w < pipe.x + pipe.w) {
      if(bird.y + bird.w > pipe.y || bird.y - bird.w < pipe.y - 120) {
        col = true;
      }
    }
  });
  return col;
}

init();
animate();