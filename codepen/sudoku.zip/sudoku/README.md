# SUDOKU

A Pen created on CodePen.io. Original URL: [https://codepen.io/cristiancanea/pen/nJzmPd](https://codepen.io/cristiancanea/pen/nJzmPd).

A common sudoku game.