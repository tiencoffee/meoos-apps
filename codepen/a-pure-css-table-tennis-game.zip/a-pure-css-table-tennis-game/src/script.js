// - No images 
// - No JavaScript 
// - Only CSS 
// ... And a few HTML radio inputs :)

// How it was made:
// https://youtu.be/MX_Y1jO_iIk

// linktr.ee/ivorjetski for more