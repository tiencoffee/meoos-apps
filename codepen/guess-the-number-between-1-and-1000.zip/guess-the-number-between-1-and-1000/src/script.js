"use strict";
const input = document.querySelector(".guess-input");
const checkBtn = document.querySelector(".guess-check");
const message = document.querySelector(".message");
const scorePoint = document.querySelector(".score-point");
const correctNumber = document.querySelector(".correct-number");
const highScorePoint = document.querySelector(".high-score-point");
const resetBtn = document.querySelector(".reset");
const highScore = 0;

let randomNumber = Math.floor(Math.random() * 1000) + 1;

checkBtn.addEventListener("click", () => {
  checkNumber(input.value);
  if (scorePoint.textContent == 0) {
    message.textContent = "😞 You lose!";
    document.body.style.backgroundColor = "#ff000055";
    document.body.style.color = "#000";
  }
  input.value = "";
});

resetBtn.addEventListener("click", () => reset());

const checkNumber = (num) => {
  if (randomNumber < num) {
    message.textContent = "📈 Too High!";
    scorePoint.textContent -= 1;
  } else if (!num) {
    message.textContent = "❌ No number!";
  } else if (randomNumber > num) {
    message.textContent = "📉 Too Low!";
    scorePoint.textContent -= 1;
  } else if (randomNumber == num) {
    correctNumber.textContent = num;
    message.textContent = "🎇 Correct Number!";
    document.body.style.backgroundColor = "#00ff0055";
    document.body.style.color = "#000";
    scorePoint.textContent > highScore
      ? (highScorePoint.textContent = scorePoint.textContent)
      : "";
  }
};

const reset = () => {
  document.body.style.backgroundColor = "#000";
  document.body.style.color = "#fff";
  message.textContent = "💤 Start guessing...";
  scorePoint.textContent = 20;
  randomNumber = Math.floor(Math.random() * 1000) + 1;
  correctNumber.textContent = "?";
};