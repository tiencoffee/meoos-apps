# Name that colour!

A Pen created on CodePen.io. Original URL: [https://codepen.io/tanner_/pen/ezZJow](https://codepen.io/tanner_/pen/ezZJow).

Simple concept - frustrating game.

Click the name of the colour that corresponds to the colour of the word!

Alter the difficulty by increasing or decreasing the timer in the wg() function.