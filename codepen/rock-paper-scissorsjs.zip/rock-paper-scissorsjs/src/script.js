//data

const computerChoiceDipslay = document.getElementById(`computerInput`);
const userChoiceDisplay = document.getElementById(`userInput`);
const resultDisplay = document.getElementById(`result`);
const possibleChoices = document.querySelectorAll('button');
let userChoice
let computerChoice
let result

possibleChoices.forEach(possibleChoices => possibleChoices.addEventListener(`click`, (e) => {
userChoice = e.target.id
userChoiceDisplay.innerHTML = userChoice;
//called function for comp gen so it works at the same time as user input
genCompChoice();
getResult();
}));


function genCompChoice() {
const randomNumber = Math.floor(Math.random() * 3)+ 1;

if (randomNumber === 1){
    computerChoice = `Rock`
}
if (randomNumber === 2){
    computerChoice = `Paper`
}
if (randomNumber === 3){
    computerChoice = `Scissors`
}
computerChoiceDipslay.innerHTML = computerChoice;
}

function getResult () {
    if (computerChoice === userChoice){
        result = `It's a draw 🥱`
    }
    if (computerChoice === `Rock` && userChoice === `Scissors`){
    result = `Computer wins! 💻 🎉`
    }
    if (computerChoice === `Paper` && userChoice === `Rock`){
    result = `Computer wins! 💻 🎉`
    }
    if (computerChoice === `Scissors` && userChoice === `Paper`){
    result = `Computer wins! 💻 🎉`
    }

    if (userChoice === `Rock` && computerChoice === `Scissors`){
        result = `User wins! 😊 🎉`
        }
        if (userChoice === `Paper` && computerChoice === `Rock`){
        result = `User wins! 😊 🎉`
        }
        if (userChoice === `Scissors` && computerChoice === `Paper`){
        result = `User wins! 😊 🎉`
        }
        resultDisplay.innerHTML = result;
    
}