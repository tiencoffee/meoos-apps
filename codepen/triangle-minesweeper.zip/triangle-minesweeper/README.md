# Triangle Minesweeper

A Pen created on CodePen.io. Original URL: [https://codepen.io/glopezma/pen/jGxgJE](https://codepen.io/glopezma/pen/jGxgJE).

Right click to mark bombs by making the cell red.  Left click to reveal the cell. Push space to restart. push up or down arrow to increase/decrease the number of bombs. Starting number of bombs is 45. 