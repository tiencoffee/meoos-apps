# 🌎 Save The Planet! 🌎

A Pen created on CodePen.io. Original URL: [https://codepen.io/kitjenson/pen/poKGYpe](https://codepen.io/kitjenson/pen/poKGYpe).

Defend Earth in this relatively simple game. Click to fire.

This is a work in progress.