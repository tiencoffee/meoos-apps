# Train Puzzle

A Pen created on CodePen.io. Original URL: [https://codepen.io/johan-tirholm/pen/xoNPzN](https://codepen.io/johan-tirholm/pen/xoNPzN).

UPDATE: Now works on touch devices also 🎉

Click on the rail tiles to swap tiles to create a path from the start (tunnel) to the end (arrow shaped  tile). When the train enters a new tile that tile is no longer movable.

Click the tile you want to move, then where you want to place it.

Levels are randomly generated but should always be solvable.

Inspired by the hacking minigame in Bioshock 1

I hope you like it :)