# Fishing Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/MarioD/pen/ymzNOO](https://codepen.io/MarioD/pen/ymzNOO).

Click and hold your mouse button, press any key, or tap on your phone to move the anchor.

Fill the bar to catch the fish.

Based on the fishing game from Stardew Valley.