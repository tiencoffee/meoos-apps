const rgbDisplay = document.querySelector('.rgb-display');
const colorBox = document.querySelectorAll('.color-box');
const msg = document.querySelector('.msg');
const livesDisplay = document.querySelector('.lives');
const scoreDisplay = document.querySelector('.score');
const highscoreDisplay = document.querySelector('.highscore');
let randId;
let lives = 5;
let score = 0;
let cooldown = false;
let highscore = 0;

const init = () => {
  // --- GENERATING RGB VALUES ---
  randId = Math.trunc(Math.random() * 6);
  const rgbRand = () => {
    const r = Math.trunc(Math.random() * 255);
    const g = Math.trunc(Math.random() * 255);
    const b = Math.trunc(Math.random() * 255);
    return `rgb(${r}, ${g}, ${b})`;
  };
  // --- SETTING RGB VALUES TO BOXES ---
  rgbDisplay.textContent = rgbRand();
  for (let box of colorBox) {
    box.style.backgroundColor = `${rgbRand()}`;
  }
  colorBox[randId].style.backgroundColor = rgbDisplay.textContent;
};
init();

const updatingStats = () => {
    livesDisplay.textContent = `Lives: ${lives}`;
    scoreDisplay.textContent = `Points: ${score}`;
    highscoreDisplay.textContent = `Highscore: ${highscore}`;
}

colorBox.forEach(e => {
  e.addEventListener('click', () => {
    if (!cooldown) {
      if (e.style.backgroundColor === rgbDisplay.textContent) {
        // --- RIGHT GUESS ---
        cooldown = true;
        msg.textContent = 'GOOD JOB!';
        msg.classList.add('good');
        msg.classList.remove('wrong');
        rgbDisplay.style.color = rgbDisplay.textContent;
        setTimeout(() => {
          msg.classList.remove('good');
          msg.textContent = '';
          init();
          cooldown = false;
          rgbDisplay.style.color = '#e0dfdc';
        }, 2000);
        score++;
        updatingStats()
      } else {
        // --- WRONG GUESS ---
        msg.textContent = 'WRONG! TRY AGAIN';
        msg.classList.add('wrong');
        lives--;
        updatingStats()
        if (!lives) {
          // --- GAME LOST ---
          cooldown = true;
          msg.textContent = 'YOU LOST';
          setTimeout(() => {
            if (score > highscore) {
              highscore = score;
            }
            score = 0;
            lives = 5;
            updatingStats()
            msg.textContent = '';
            cooldown = false;
            init();
          }, 2000);
        }
      }
    }
  });
});
