import * as THREE from 'https://cdn.skypack.dev/three@0.140.2';

const playBtnScreen = document.getElementById("play-btn-screen");

const playBtn = playBtnScreen.querySelector("#play-btn");

var allObjs = [];

const keyBtns = document.querySelectorAll(".keys-container button");

let camera, scene, renderer, player;

let speed = 0.10;

const boxSideLength = 0.5;

const courseLength = 100;

const gridHelperSize = courseLength * 2;

let gameOver = false;

const numOfObstacles = 50;

var obstaclesBoundingBoxes = [];

// limit movement of player box on x and y-axis 

const xBoundary = 4 - (boxSideLength / 2);

const yBoundary = xBoundary / 4;

init();

function init() {

  scene = new THREE.Scene();

  camera = new THREE.PerspectiveCamera(

    70,

    window.innerWidth / window.innerHeight,

    0.1,

    200

  );

  camera.position.set(4, 4, -4);

  camera.lookAt(0, 0, 2);

  const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);

  const directionalLight = new THREE.DirectionalLight(0xffffff, 0.6);

  directionalLight.position.set(10, 20, 0);

  scene.add(ambientLight, directionalLight);

  initializeBoxes();

  const gridHelper = new THREE.GridHelper(gridHelperSize, gridHelperSize);

  scene.add(gridHelper);

  renderer = new THREE.WebGLRenderer({ antialias: true });

  renderer.setSize(window.innerWidth, window.innerHeight);

  renderer.render(scene, camera);

  //animate();

  document.body.appendChild(renderer.domElement);

}

function createBox(x, y, z) {

  const geometry = new THREE.BoxGeometry(

    boxSideLength,

    boxSideLength,

    boxSideLength

  );

  const material = new THREE.MeshLambertMaterial({ color: 0xe56956 });

  const mesh = new THREE.Mesh(geometry, material);

  mesh.position.set(x, y, z);

  allObjs.push(mesh);

  scene.add(mesh);

  return {

    mesh,

  };

}

function createObstacle() {

  const x = THREE.MathUtils.randFloatSpread(xBoundary * 2);

  const y = THREE.MathUtils.randFloatSpread(yBoundary * 2);

  const z = THREE.MathUtils.randFloat(10, courseLength - boxSideLength);

  const obstacle = createBox(x, y, z);

  const boundingBox = new THREE.Box3().setFromObject(obstacle.mesh);

  obstaclesBoundingBoxes.push(boundingBox);

}

function detectCollisions() {

  const playerBox = new THREE.Box3().setFromObject(player.mesh);

  // Check each object to detect if there is a collision

  for (let i = 0; i < numOfObstacles + 1; i++) {

    // an object was hit

    if (obstaclesBoundingBoxes[i].intersectsBox(playerBox)) {

      gameOver = true;

      playBtnScreen.style.visibility = "visible";

      playBtn.focus();

      if (i !== numOfObstacles) {

        alert("You lose");

      } else {

        // the last box is the finish line box

        alert("You win!");

      }

      return;

    }

  }

}

function initializeBoxes() {

  // make empty at start of a game

  allObjs = [];

  obstaclesBoundingBoxes = [];

  

  player = createBox(0, 0, 0);

  for (let i = 0; i < numOfObstacles; i++) {

    createObstacle();

  }

  // create finish line box

  const geometry = new THREE.BoxGeometry(

    xBoundary * 2,

    yBoundary * 2,

    boxSideLength

  );

  const material = new THREE.MeshLambertMaterial({ color: "green" });

  const mesh = new THREE.Mesh(geometry, material);

  mesh.position.set(0, 0, courseLength);

  allObjs.push(mesh);

  scene.add(mesh);

  const boundingBox = new THREE.Box3().setFromObject(mesh);

  obstaclesBoundingBoxes.push(boundingBox);

}

function animate() {

  if (gameOver) return;

  player.mesh.position.z += speed;

  camera.position.z += speed;

  detectCollisions();

  renderer.render(scene, camera);

  requestAnimationFrame(animate);

}

// moving player box with arrow keys

window.addEventListener("keydown", (e) => {

  if (gameOver) return;

  const key = e.key;

  const currXPos = player.mesh.position.x;

  const currYPos = player.mesh.position.y;

  if (key === "ArrowLeft") {

    if (currXPos > xBoundary) return;

    player.mesh.position.x += speed;

  }

  if (key === "ArrowRight") {

    if (currXPos < -xBoundary) return;

    player.mesh.position.x -= speed;

  }

  if (key === "ArrowUp") {

    if (currYPos > yBoundary) return;

    player.mesh.position.y += speed;

  }

  if (key === "ArrowDown") {

    if (currYPos < -yBoundary) return;

    player.mesh.position.y -= speed;

  }

});

playBtn.addEventListener("click", () => {

  allObjs.forEach((obj) => scene.remove(obj));

  camera.position.set(4, 4, -4);

  camera.lookAt(0, 0, 2);

  initializeBoxes();

  gameOver = false;

  animate();

  playBtnScreen.style.visibility = "hidden";

});

let timeoutID = 0;

function moveLeft() {

  const currXPos = player.mesh.position.x;

  if (currXPos > xBoundary) return;

  player.mesh.position.x += speed;

  clearTimeout(timeoutID);

  timeoutID = setTimeout(moveLeft, 50);

}

function moveRight() {

  const currXPos = player.mesh.position.x;

  if (currXPos < -xBoundary) return;

  player.mesh.position.x -= speed;

  clearTimeout(timeoutID);

  timeoutID = setTimeout(moveRight, 50);

}

function moveUp() {

  const currYPos = player.mesh.position.y;

  if (currYPos > yBoundary) return;

  player.mesh.position.y += speed;

  clearTimeout(timeoutID);

  timeoutID = setTimeout(moveUp, 50);

}

function moveDown() {

  const currYPos = player.mesh.position.y;

  if (currYPos < -yBoundary) return;

  player.mesh.position.y -= speed;

  clearTimeout(timeoutID);

  timeoutID = setTimeout(moveDown, 50);

}

function handleKeyDown(e) {

  if (gameOver) return;

  const { id } = e.currentTarget;

  if (id === "left") {

    moveLeft();

  }

  if (id === "right") {

    moveRight();

  }

  if (id === "up") {

    moveUp();

  }

  if (id === "down") {

    moveDown();

  }

}

// moving box - mobile - using screen btns

keyBtns.forEach((keyBtn) => {

  keyBtn.addEventListener("mousedown", handleKeyDown);

  keyBtn.addEventListener("touchstart", handleKeyDown);

  keyBtn.addEventListener("mouseup", () => {

    clearTimeout(timeoutID);

    timeoutID = 0;

  });

  keyBtn.addEventListener("mouseleave", () => {

    clearTimeout(timeoutID);

    timeoutID = 0;

  });

  keyBtn.addEventListener("touchend", () => {

    clearTimeout(timeoutID);

    timeoutID = 0;

  });

  keyBtn.addEventListener("touchcancel", () => {

    clearTimeout(timeoutID);

    timeoutID = 0;

  });

});