# Trying To Be Victorious [Game]

A Pen created on CodePen.io. Original URL: [https://codepen.io/demaine/pen/WBmwdV](https://codepen.io/demaine/pen/WBmwdV).

Part 4 and grand finale of my little Rocket's adventure in the Codepen's Space Theme Challenge. This time it is a epic showdown between two rockets in a war amongst the stars and there can be only one winner! Shoot, blast and even bump your way to victory! 

Use the toggle on the start screen to select whether to play against a computer or human player. 

The blue rocket is controlled with AWD and shoot with Z. 

The red rocket is controlled with the Arrow Keys and shoot with Spacebar.

Now the rocket has been upgraded with a shield, every shot on target is worth 1% but crashing into asteroids causes more damage and bumping into your opponent causes mutual damage.

This was my first attempt to create a computer controlled opponent, it's not perfect but not bad for a first attempt.

This is the result of gradually building upon the ideas of each week's challenge and since the title of the challenge was plural of spaceships the first idea I had was to try and make a battle game.

Enjoy!

Best played in full screen mode and with a friend!

Check out my other [Games] (https://codepen.io/demaine/pens/tags/?selected_tag=game#)!

This is a continuation of the Space saga:

For part 1 see: [Trying To Get Your Attention] (https://codepen.io/demaine/full/KLKeaL).

For part 2 see: [Trying To Land Safely] (https://codepen.io/demaine/full/YbZVvY).

For part 3 see: [Trying To Save The Planet] (https://codepen.io/demaine/full/oRqvqE).

_Created for the [May 2019 CodePen Challenge "Spaceships"](https://codepen.io/challenges/2019/May)._
