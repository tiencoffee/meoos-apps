# Flappy Dino

A Pen created on CodePen.io. Original URL: [https://codepen.io/mlho/pen/zMejmo](https://codepen.io/mlho/pen/zMejmo).

Flap your way through obstacles and score