// Don't look here for some JS code
// You will not found any of this here
// Another Pure CSS game
// Made by Itzik Pop
// Contact me @ https://www.linkedin.com/in/itzikpop/