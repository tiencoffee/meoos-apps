# Colour Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/MarioDesigns/pen/gGEXde](https://codepen.io/MarioDesigns/pen/gGEXde).

Try to spot it to level up, gess wrong and you will lose a life, see how far you can get.