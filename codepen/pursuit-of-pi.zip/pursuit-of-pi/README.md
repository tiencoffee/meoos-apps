# Pursuit of PI

A Pen created on CodePen.io. Original URL: [https://codepen.io/jak_e/pen/rYxKBw](https://codepen.io/jak_e/pen/rYxKBw).

A game with a dynamic soundtrack. Life is the Pursuit of PI.