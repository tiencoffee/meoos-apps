# Sequence - The Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/iammenasco/pen/PoVMyV](https://codepen.io/iammenasco/pen/PoVMyV).

UNDER CONSTRUCTION - Based of finding the sequence in an array (in a previous pen), you race the clock to find the sequence yourself!