# Snake Game - Javascript

A Pen created on CodePen.io. Original URL: [https://codepen.io/ruthinunes/pen/WNaQjMJ](https://codepen.io/ruthinunes/pen/WNaQjMJ).

This is a simple snake game developed with JavaScript. It was created as a way to test beginner programming skills with JS.

If you liked this project or have any question, suggestion, advice or tips, I look forward to hearing from you!

https://linktr.ee/ruthinunes
