# Good Burger mini game for old CodePen challenge

A Pen created on CodePen.io. Original URL: [https://codepen.io/jcoulterdesign/pen/yKVrbx](https://codepen.io/jcoulterdesign/pen/yKVrbx).

