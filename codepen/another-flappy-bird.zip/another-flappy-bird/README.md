# Another Flappy Bird

A Pen created on CodePen.io. Original URL: [https://codepen.io/Karl-H/pen/wvgaNNP](https://codepen.io/Karl-H/pen/wvgaNNP).

Simple shapes and JS to make yet another Flappy Bird game 😉
Best played in side tabs or debug view.