# CSS Rock-Paper-Scissors

A Pen created on CodePen.io. Original URL: [https://codepen.io/alvaromontoro/pen/BaaBYyz](https://codepen.io/alvaromontoro/pen/BaaBYyz).

A Rock-Paper-Scissor game developed in HTML+CSS without any JavaScript.