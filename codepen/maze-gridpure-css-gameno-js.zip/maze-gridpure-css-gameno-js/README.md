# Maze (Grid) - Pure CSS Game - No JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/chaofix/pen/VrWZga](https://codepen.io/chaofix/pen/VrWZga).

A little game to demonstrate how can create a game without Java Script at all and using only pure CSS