# the Last War

A Pen created on CodePen.io. Original URL: [https://codepen.io/lucagez/pen/aYejzo](https://codepen.io/lucagez/pen/aYejzo).

Simple html  game with factories that randomly colonize the world. You need to contrast them by planting trees on every square.

Icons made by https://freepik.com  