const { useState, useEffect } = React;

const Shape = ({ className = "shape-1" }) => (
  <svg className={`shape ${className}`} viewBox="0 0 200 200" fill="none">
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M100 0C100 55.2285 55.2285 100 0 100C55.2285 100 100 144.772 100 200C100 144.772 144.772 100 200 100C144.772 100 100 55.2285 100 0Z"
      fill="inherit"
    />
  </svg>
);

const IconButton = ({ isRound, icon, onClick }) => {
  const iconShape = isRound ? "round" : "squared";
  return (
    <button
      onClick={onClick}
      className={`icon-button flex-center ${iconShape} ${iconShape}`}
    >
      <span className="material-icons-outlined">{icon}</span>
    </button>
  );
};

const Number = ({ text, isClear, onClick }) => {
  const type = isClear ? "clear" : "number";
  return (
    <button onClick={onClick} className={`number-button flex-center ${type}`}>
      <span className="number-text">{text}</span>
    </button>
  );
};

const Time = () => {
  const [totalSeconds, setTotalSeconds] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const minutes = Math.floor(totalSeconds / 60);

  const toggle = () => {
    setIsActive(!isActive);
  };

  useEffect(() => {
    setIsActive(true);
  }, []);

  useEffect(() => {
    let interval = null;
    if (isActive) {
      interval = setInterval(() => {
        setTotalSeconds((seconds) => seconds + 1);
        setSeconds((seconds) => (seconds < 59 ? seconds + 1 : 0));
      }, 1000);
    } else if (!isActive && seconds !== 0) {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isActive, seconds]);

  return (
    <div className="time d-flex align-items-center">
      <span className="time-text">
        {minutes < 10 ? `0${minutes}` : minutes}:
        {seconds < 10 ? `0${seconds}` : seconds}
      </span>
      <IconButton
        onClick={toggle}
        icon={isActive ? "pause" : "play_arrow"}
        isRound
      />
    </div>
  );
};

const Header = () => (
  <header className="d-flex">
    <IconButton icon="keyboard_backspace" />
    <div className="ml-auto">
      <IconButton icon="palette" />
    </div>
    <div className="ml-15">
      <IconButton icon="help_outline" />
    </div>
    <div className="ml-15">
      <IconButton icon="settings" />
    </div>
  </header>
);

const SubHeader = () => (
  <div className="sub-header d-flex align-items-center">
    <h1 className="sub-header-title">Easy</h1>
    <span className="ml-auto mistake-text">
      Mistake: <span className="mistake-number">1/5</span>
    </span>
  </div>
);

const Game = ({ puzzle, onSelectInput, onHandleChange }) => {
  const [selectedRow, setSelectedRow] = useState(0);
  const [selectedCol, setSelectedCol] = useState(0);

  const onHandleFocus = (isPreFilled, index) => {
    if (!isPreFilled) {
      const currSelectedRow = Math.ceil((index + 1) / 9);
      setSelectedRow(currSelectedRow);
      setSelectedCol(index + 1 - 9 * (currSelectedRow - 1));
    }
  };

  return (
    <div className="game-container">
      {[...Array(4)].map((_, index) => {
        return <Shape key={index} className={`shape-${index + 1}`} />;
      })}
      <div
        className={`game-wrapper select-row-${selectedRow} select-col-${selectedCol}`}
      >
        {puzzle.map(({ value, isPreFilled }, index) => {
          return (
            <input
              key={index}
              value={value}
              readOnly={isPreFilled}
              tabIndex={isPreFilled ? -1 : 0}
              className={`game-input ${isPreFilled ? "prefilled-text" : ""}`}
              type="text"
              maxLength="1"
              name={`game-input-${index}`}
              onChange={(e) => onHandleChange(e)}
              onFocus={() => {
                onHandleFocus(isPreFilled, index);
                onSelectInput(index);
              }}
              onBlur={() => {
                setSelectedRow(0);
                setSelectedCol(0);
              }}
            />
          );
        })}
      </div>
    </div>
  );
};

const Actions = () => (
  <div className="actions d-flex">
    <IconButton icon="undo" isRound />
    <div className="ml-15">
      <IconButton icon="edit" isRound />
    </div>
    <div className="ml-15">
      <IconButton icon="lightbulb" isRound />
    </div>
    <div className="ml-auto">
      <Time />
    </div>
  </div>
);

const Numbers = ({ onClick, onClear }) => (
  <div className="numbers">
    {[...Array(9)].map((_, index) => {
      return (
        <Number
          key={index}
          text={index + 1}
          onClick={() => {
            onClick(index + 1);
          }}
        />
      );
    })}
    <Number onClick={onClear} text="&#10005;" isClear />
  </div>
);

const App = () => {
  const [selectedInput, setSelectedInput] = useState(null);
  const puzzle =
    "5...8..49...5...3..673....115..........2.8..........187....415..3...2...49..5...3";
  const puzzleArr = puzzle.split("");
  const [puzzleObj, setPuzzleObj] = useState(
    puzzleArr.map((item, id) => {
      return {
        id,
        value: item !== "." ? item : "",
        isPreFilled: item !== "."
      };
    })
  );

  const onHandleChange = (value, clearValue) => {
    const isValueValid = (/^\d+$/.test(value) && value !== "0") || clearValue;

    setPuzzleObj((prevItems) =>
      prevItems.map((item) =>
        isValueValid && !item.isPreFilled && item.id === selectedInput
          ? {
              id: item.id,
              value,
              isPreFilled: false
            }
          : item
      )
    );
  };

  return (
    <div className="App">
      <div className="container">
        <Header />
        <SubHeader />
        <Game
          puzzle={puzzleObj}
          onSelectInput={(value) => setSelectedInput(value)}
          onHandleChange={(e) => onHandleChange(e.target.value)}
        />
        <Actions />
        <Numbers
          onClick={(value) => onHandleChange(value)}
          onClear={() => onHandleChange("", true)}
        />
      </div>
    </div>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
