# speed code #2 - BJIeH - maze player

A Pen created on CodePen.io. Original URL: [https://codepen.io/towc/pen/JWgeMR](https://codepen.io/towc/pen/JWgeMR).

55:50. This is really helping in estimations :P