# Block Puzzle Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/charlie-volpe/pen/jOGPed](https://codepen.io/charlie-volpe/pen/jOGPed).

This is a 25 level block puzzle game.

Rules:
1. This is a game of matching colors. When three match up they will go away and you will get points. Only three will clear if more than three of the same color touch.
2. Click on a row and the entire row will move to the top of the column.
3. When the blocks are cleared the blocks on the right will move left in their own row.
4. The fewer the clicks made the more points you will gain.