# Breakout

A Pen created on CodePen.io. Original URL: [https://codepen.io/adelciotto/pen/bGLZpr](https://codepen.io/adelciotto/pen/bGLZpr).

A small breakout game I wrote during my early university years. I apologize for the quality of the code. Press shift to launch the ball, and the arrow keys to move left & right.