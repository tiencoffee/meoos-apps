# WordlePractice

A Pen created on CodePen.io. Original URL: [https://codepen.io/jfledd/pen/ExwGqrz](https://codepen.io/jfledd/pen/ExwGqrz).

