# React Game- Elephant Taco Hunt

A Pen created on CodePen.io. Original URL: [https://codepen.io/sdras/pen/YWBdQd](https://codepen.io/sdras/pen/YWBdQd).

This game is built with React, SVG, and GreenSock. It's about a hipster elephant who wants to get tacos but his friends keep trying to change plans and text him. Margaritas are extra points. This game is based on real life events. Someday I'll convert it to ES6.