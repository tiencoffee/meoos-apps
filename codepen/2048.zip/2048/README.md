# 2048

A Pen created on CodePen.io. Original URL: [https://codepen.io/ramenhog/pen/JWZzry](https://codepen.io/ramenhog/pen/JWZzry).

A friend challenged me to build 2048 a while back...I finally did it :)