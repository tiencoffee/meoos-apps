# React Memory Game 

A Pen created on CodePen.io. Original URL: [https://codepen.io/mikun/pen/jMRJjq](https://codepen.io/mikun/pen/jMRJjq).

A small memory game made by ReactJS - ES6 syntax

Inspired by [Tuan, my colleague](https://www.facebook.com/nguyen.tuan192)