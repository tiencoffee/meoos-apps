# Snake Tales <Game>

A Pen created on CodePen.io. Original URL: [https://codepen.io/RaoXdev/pen/XWxzvMm](https://codepen.io/RaoXdev/pen/XWxzvMm).

Bring out your inner kid and Enjoy the Vintage popular Snake Games you played on Nokia