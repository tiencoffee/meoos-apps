# CSS Only Room Escape Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/takaneichinose/pen/YzqreVp](https://codepen.io/takaneichinose/pen/YzqreVp).

This is an escape game only made in CSS.

I created all of the assets, using MS paint to draw the image, and Paint.net to make the background color of the PNG files into transparent.

These functions are just made my many hidden checkboxes, and radio buttons.

Instructions are already written the game.

Please do not look on the source code, to find the clues to go outside.

Keep in mind that there are concealed object in the game. I haven't written it on the instructions, but basically, it has.

There are 5 stages to complete.

If you completed the game, please challenge your friends to do the puzzle too. It is recommended to play this game on either full-screen mode, or debug mode, to avoid accidentally looking on the source code.

Please enjoy this simple game!