# Star Ship Alien Portal - Star CodePen Space Challenge with ZIM

A Pen created on CodePen.io. Original URL: [https://codepen.io/danzen/pen/OYVGPL](https://codepen.io/danzen/pen/OYVGPL).

We were going to make a bunch of really badly drawn stars but when we shuffled the points it made neat symbols that looked like stars, space ships, aliens and portals - so we made a game instead!  Try and find the shape that does not change as fast as you can to get a high score!

ZIM provides JavaScript conveniences, components and controls for the Canvas and is powered by CreateJS with its solid Bitmap Object Model (BOM). Code Creativity with ZIM!
