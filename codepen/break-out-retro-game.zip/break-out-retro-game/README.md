# Break-Out (Retro game)

A Pen created on CodePen.io. Original URL: [https://codepen.io/FRADAR/pen/mdwbVaB](https://codepen.io/FRADAR/pen/mdwbVaB).

A break-out game made in canvas.