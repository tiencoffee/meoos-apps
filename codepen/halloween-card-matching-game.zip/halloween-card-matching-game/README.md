# Halloween Card Matching Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/WebDevSimplified/pen/EdEjyx](https://codepen.io/WebDevSimplified/pen/EdEjyx).

