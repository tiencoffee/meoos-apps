# Vanilla JS Snake

A Pen created on CodePen.io. Original URL: [https://codepen.io/fariati/pen/mdRpEYP](https://codepen.io/fariati/pen/mdRpEYP).

This is a snake game I made with Vanilla Javascript.