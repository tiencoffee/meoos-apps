# JS Planet defense game

A Pen created on CodePen.io. Original URL: [https://codepen.io/Loopez10/pen/dMaVdQ](https://codepen.io/Loopez10/pen/dMaVdQ).

Protect the planet! Destroy the asteroids to save your people! 
It's my first canvas game, enjoy it! :)

(Recommended to play in FULL PAGE VIEW)