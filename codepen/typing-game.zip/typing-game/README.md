# Typing Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/jjmartucci/pen/YqKqpJ](https://codepen.io/jjmartucci/pen/YqKqpJ).

Typing game. Type as many words as you can in 60 seconds. Post your high score in the comments!

If you want a challenge, try playing on your phone.