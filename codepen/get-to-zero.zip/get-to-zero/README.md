# Get to zero

A Pen created on CodePen.io. Original URL: [https://codepen.io/learosema/pen/NGJyxx](https://codepen.io/learosema/pen/NGJyxx).

A simple game made in my typical esoteric coding style ☺. 

Click on a tile. Adjacent tiles with the same numbers will be removed and the clicked tile's number will be decreased. New numbers fall from the top of the screen. The aim of the game is to get a tile to zero.  

Tried to keep it #50lines||less, but I didn't want to make the code less readable than it actually is right now :D still pretty short ;)

UPDATE:  I've experienced a bug that caused a number to be decreased twice sometimes  in Chrome - it occurs very rarely. I (hopefully) fixed that ☺. Please let me know if that still happens.