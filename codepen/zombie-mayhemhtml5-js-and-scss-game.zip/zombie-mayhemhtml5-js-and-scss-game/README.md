# Zombie Mayhem - HTML5, JS and SCSS Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/eliortabeka/pen/RoNgzR](https://codepen.io/eliortabeka/pen/RoNgzR).

#####Kill or be eaten in the Zombie Mayhem