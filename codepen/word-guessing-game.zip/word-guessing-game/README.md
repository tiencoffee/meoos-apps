# Word Guessing Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/natewiley/pen/MWyWmK](https://codepen.io/natewiley/pen/MWyWmK).

My first attempt at a game in JS.. Guess from over 70 web related words! Hope you like it :)